/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=16x16 fruitImage fruitImage.png 
 * Time-stamp: Saturday 04/02/2022, 17:37:54
 * 
 * Image Information
 * -----------------
 * fruitImage.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FRUITIMAGE_H
#define FRUITIMAGE_H

extern const unsigned short fruitImage[256];
#define FRUITIMAGE_SIZE 512
#define FRUITIMAGE_LENGTH 256
#define FRUITIMAGE_WIDTH 16
#define FRUITIMAGE_HEIGHT 16

#endif

