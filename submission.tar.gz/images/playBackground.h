/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 playBackground playBackground.jpg 
 * Time-stamp: Saturday 04/02/2022, 04:21:57
 * 
 * Image Information
 * -----------------
 * playBackground.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYBACKGROUND_H
#define PLAYBACKGROUND_H

extern const unsigned short playBackground[38400];
#define PLAYBACKGROUND_SIZE 76800
#define PLAYBACKGROUND_LENGTH 38400
#define PLAYBACKGROUND_WIDTH 240
#define PLAYBACKGROUND_HEIGHT 160

#endif

