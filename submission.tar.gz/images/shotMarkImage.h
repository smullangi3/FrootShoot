/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=9x9 shotMarkImage shotMarkImage.png 
 * Time-stamp: Saturday 04/02/2022, 05:15:04
 * 
 * Image Information
 * -----------------
 * shotMarkImage.png 9@9
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SHOTMARKIMAGE_H
#define SHOTMARKIMAGE_H

extern const unsigned short shotMarkImage[81];
#define SHOTMARKIMAGE_SIZE 162
#define SHOTMARKIMAGE_LENGTH 81
#define SHOTMARKIMAGE_WIDTH 9
#define SHOTMARKIMAGE_HEIGHT 9

#endif

