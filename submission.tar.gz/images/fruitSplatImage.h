/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 fruitSplatImage fruitSplatImage.png 
 * Time-stamp: Saturday 04/02/2022, 21:53:11
 * 
 * Image Information
 * -----------------
 * fruitSplatImage.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FRUITSPLATIMAGE_H
#define FRUITSPLATIMAGE_H

extern const unsigned short fruitSplatImage[256];
#define FRUITSPLATIMAGE_SIZE 512
#define FRUITSPLATIMAGE_LENGTH 256
#define FRUITSPLATIMAGE_WIDTH 16
#define FRUITSPLATIMAGE_HEIGHT 16

#endif

