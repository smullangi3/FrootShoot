/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 startBackground startBackground.png 
 * Time-stamp: Sunday 04/03/2022, 02:54:26
 * 
 * Image Information
 * -----------------
 * startBackground.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTBACKGROUND_H
#define STARTBACKGROUND_H

extern const unsigned short startBackground[38400];
#define STARTBACKGROUND_SIZE 76800
#define STARTBACKGROUND_LENGTH 38400
#define STARTBACKGROUND_WIDTH 240
#define STARTBACKGROUND_HEIGHT 160

#endif

